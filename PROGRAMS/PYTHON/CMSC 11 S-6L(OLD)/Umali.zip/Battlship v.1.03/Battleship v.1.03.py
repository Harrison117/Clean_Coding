

## Reference: https://docs.python.org/3/library/random.html
import random

################
################
## AESTHETICS ##
################
################

import time

def border():
    for i in range(4):
        if i==1 or i==2:
            print('[]'*30)
        else:
            print()
            print()
    
def menu():
    '''
            S.Y.V.N presents...
            
   ---------------                   |__
   | Battleship: |                   |\/
   |    The Game |                   ---
   ---------------                 / | [
                              !      | |||
                            _/|     _/|-++'
                        +  +--|    |--|--|_ |-
                     { /|__|  |/\__|  |--- |||__/
                    +---------------___[}-_===_.'____
                ____`-' ||___-{]_| _[}-  |     |_[___\==--
     __..._--==/___]_|__|_____________________________[___\==--_,------' .7
    |                                          Art by Matthew Bace       /
     \__________________________________________________________________|
     
     []start
     []load
     []hall of fame
     []exit
     
    '''

def quotes():
    quote=random.randrange(1,6)
    if quote==1:
        border()
        print("If you can't see the enemy, he still may be able to see you.\n                -Murphy's Laws of War")
        border()
        print("Please wait...")
        time.sleep(5.00)
        return
    elif quote==2:
        border()
        print("...if fighting is sure to result in victory then you must fight...!\n                -Sun Tzu's Art of War")
        border()
        print("Please wait...")
        time.sleep(5.00)
        return
    elif quote==3:
        border()
        print("There are two ways to do something:\n   the right way and again\n                -The Navy SEALS")
        border()
        print("Please wait...")
        time.sleep(5.00)
        return
    elif quote==4:
        border()
        print("    We do not fear the unknown...\nWe fear what we project into the unknown.\n            -Teal Swan")
        border()
        print("Please wait...")
        time.sleep(5.00)
        return
    
def briefing():
    '''
An unknown number of unidentified objects have landed on the pacific ocean. The world has been alarmed of such occurrence. 

Tensions are high.

Weather patterns has been distrupted by the movement of hostile, foreign objects. 

Codenamed "Abyssals", they have taken over half of the Earth's waters and cut off our trade routes.

It's up to you, admiral, and your fleet to stop the invading "Abyssals" from taking over our waters, or worse our planet...

End of transmission

    '''

def briefing_intel():
    '''
Admiral! We have intelligence on the enemy ships. It seems that they've developed some sort of a 'cloaking' device.

Its up to you now on where we will attack.

Good luck commander!

    '''
def dev(select_dev):
    ## Used for restarting, etc. the game for testing
    border()
    border()
    border()
    select_dev=input("ACTIONS:\n[1]RESTART\n[2]TEST UI GRID\n[3]EXIT\n[] ")
    grid=[
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 1, 1, 1, 1, 1, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 1, 0, 0, 0], 
    [0, 0, 0, 1, 0, 0, 1, 0, 0, 0], 
    [0, 0, 0, 1, 0, 0, 1, 0, 0, 0], 
    [0, 0, 0, 1, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 1, 1, 0, 0, 1, 1, 1, 1, 0], 
    [0, 0, 0, 0, 0, -1, 0, 0, 0, 0]]
    if select_dev=='1':
        ## Reference: [http://stackoverflow.com/questions/436198/what-is-an-alternative-to-execfile-in-python-3-0]
        border()
        border()                    
        with open("Battleship v.1.03.py") as f:
            code = compile(f.read(), "Battleship v.1.03.py", 'exec')
            exec(code)
    elif select_dev=='2':
        grid_AI_ui(grid)
        input()
        grid_player_ui(grid)
        input()
    elif select_dev=='3':
        return

###############
###############
## MAIN CODE ##
###############
###############
    
def initialize_grid():
    grid=[]
    grid_builder=[]
    for v in range(0,10):
        for h in range(0,10):
            grid_builder.append(0)
        grid.append(grid_builder)
        grid_builder=[]
    return grid


def grid_AI_ui(gridofAI):
    for v_coord in range(0,2):
        if v_coord==0:
            print("[]     ",end="")
        else:
            print("[] ",end="")
        for h_coord in range(0,10):
            if v_coord==1:
                print("  ",end="")
            elif v_coord==0:
                print(" ",end="")
                print(h_coord,end="")
        print()
    for v in range(0,10):
        print("[] ",v," ",end="")
        for h in range(0,10):
            print("|",end="")
            if gridofAI[v][h]==-1:
                print("#",end="")
            elif gridofAI[v][h]==0 or gridofAI[v][h]==1:
                print(".",end="")
            elif gridofAI[v][h]==2:
                print("x",end="")
        print("|   ",end="")
        print(v)
    for v_coord in range(0,2):
        if v_coord==0:
            print("[]  ",end="")
        else:
            print("[]     ",end="")
        for h_coord in range(0,10):
            if v_coord==0:
                print("  ",end="")
            elif v_coord==1:
                print(" ",end="")
                print(h_coord,end="")
        print()
    print()


def grid_player_ui(gridofplayer):
    for v_coord in range(0,2):
        if v_coord==0:
            print("[]     ",end="")
        else:
            print("[] ",end="")
        for h_coord in range(0,10):
            if v_coord==1:
                print("  ",end="")
            elif v_coord==0:
                print(" ",end="")
                print(h_coord,end="")
        print()
    for v in range(0,10):
        print("[] ",v," ",end="")
        for h in range(0,10):
            print("|",end="")
            if gridofplayer[v][h]==-1:
                print("#",end="")
            elif gridofplayer[v][h]==0:
                print(".",end="")
            elif gridofplayer[v][h]==1:
                print("o",end="")
            elif gridofplayer[v][h]==2:
                print("x",end="")
        print("|   ",end="")
        print(v)
    for v_coord in range(0,2):
        if v_coord==0:
            print("[]  ",end="")
        else:
            print("[]     ",end="")
        for h_coord in range(0,10):
            if v_coord==0:
                print("  ",end="")
            elif v_coord==1:
                print(" ",end="")
                print(h_coord,end="")
        print()
    print()

            
def hor_or_ver():
    print(" o -->")
    for i in range(0,2):
        if i==1:
            print(" v")
        else:
            print(" |")
    border()
    while True:
        n=input("Horizontal or vertical placement? h/v []")
        if n=='h':
            return True
        elif n=='v':
            return False
        else:
            print("[] h (Horizontal) or v (Vertical) only.")

            
def ship_place_confirm(x,y,grid_placing,orientation,ship_list,ship,player=None):
    tries=0 ## Used as counter until test ship placement goes out of bounds
    for i in range(0,ship_list[ship]):
        try:
            if orientation: ## Horizontal
                if grid_placing[y][x+i]!=1:
                    grid_placing[y][x+i]=1
                    tries+=1 ## Counts the part tested and placed for use in exception handler
                else:
                    for i in range(0,tries):
                        grid_placing[y][x+i]=0
                    if player:    
                        input("Invalid placement, try again...")
                    return False
            else: ## Vertical
                if grid_placing[y+i][x]!=1:
                    grid_placing[y+i][x]=1
                    tries+=1
                else:
                    for i in range(0,tries):
                        grid_placing[y+i][x]=0
                    if player:    
                        input("Invalid placement, try again...")
                    return False
        except IndexError:
            for i in range(0,tries): ## If the loop is not used, ship part during placement that go out of bounds will be left...
                                     ## To avoid that, reset the remaining ship part by using tries counter
                                     ## (The number of parts tried, tested and put in the test board before the error occurs)                
                if orientation: ## Horizontal
                    grid_placing[y][x+i]=0
                
                else: ## Vertical
                    grid_placing[y+i][x]=0
            
            if player:    
                input("Invalid placement, try again...")
            return False
    
    return True

    
def ship_place(x,y,grid,orientation,ship_list,ship):

    for i in range(0,ship_list[ship]):
    
        if orientation:
            grid[y][x+1]=1
    
        else:
            grid[y+1][x]=1

            
def hitbox_check(grid,xcoord,ycoord,ai_atk,ai_atk_counter,ai_atk_history,ai=False):

    ## -1=Missed 0=Empty 1=Ship 2=Damaged (Applies to both sides)
    
    if not(ai): ## PLAYER ATTACK
        try:
            if grid[ycoord][xcoord]==0:
                grid[ycoord][xcoord]=-1
                input("Miss!")
                return 0
            
            elif grid[ycoord][xcoord]==1:
                grid[ycoord][xcoord]=2
                input("Hit!")
                return 1
            
            elif grid[ycoord][xcoord]==2 or grid[ycoord][xcoord]==-1:
                input("Already shot there... Try again.")
                return 2
        except IndexError:
            input("Shot out of bounds...")
            return 2
    
    else: ## AI ATTACK PORTION
        while True:
            if ai_atk==0: ## From a randomized range of numbers x and y, shoots in the grid that 
                          ## would cover the grid in a criss-cross pattern
                if grid[ycoord][xcoord]==0:
                    grid[ycoord][xcoord]=-1
                    print("Shot at (",xcoord,",",ycoord,")")
                    return 0,0,ai_atk_counter,ai_atk_history
                    
                elif grid[ycoord][xcoord]==1:
                    grid[ycoord][xcoord]=2
                    ai_atk_history[ai_atk_counter]=[xcoord,ycoord]
                    ai_atk_counter+=1
                    print("Hit at (",xcoord,",",ycoord,")")
                    return 1,1,ai_atk_counter,ai_atk_history
                    
                elif grid[ycoord][xcoord]==-1 or grid[ycoord][xcoord]==2:
                    return 2,0,ai_atk_counter,ai_atk_history
                    
            elif ai_atk==1: ## Shot search if 1st shot hits
                i=ai_atk_counter
                while True:
                    try:
                        target=hit_history[i]
                        break
                    except KeyError:
                        i-=1
                        if i<0:
                            i=ai_atk_counter
                            i+=1
                        continue
                if grid[target[1]-1][target[0]]==-1 or grid[target[1]-1][target[0]]==2:
                    if grid[target[1]][target[0]+1]==-1 or grid[target[1]][target[0]+1]==2:
                        if grid[target[1]+1][target[0]]==-1 or grid[target[1]+1][target[0]]==2:
                            if grid[target[1]][target[0]-1]==-1 or grid[target[1]][target[0]-1]==2:
                                hit_history.pop(i)
                                ai_atk=0
                                continue
                            else:
                                if grid[target[1]][target[0]-1]==0:
                                    grid[target[1]][target[0]-1]=-1
                                    print("Shot at (",target[0]-1,",",target[1],")")
                                    return 0,1,ai_atk_counter,ai_atk_history
                                    
                                elif grid[target[1]][target[0]-1]==1:
                                    grid[target[1]][target[0]-1]=2
                                    print("Hit at (",target[0]-1,",",target[1],")")
                                    return 1,1,ai_atk_counter,ai_atk_history
                                    
                        else:
                            if grid[target[1]+1][target[0]]==0:
                                grid[target[1]+1][target[0]]=-1
                                print("Shot at (",target[0],",",target[1]+1,")")
                                return 0,1,ai_atk_counter,ai_atk_history
                            
                            elif grid[target[1]+1][target[0]]==1:
                                grid[target[1]+1][target[0]]=2
                                print("Hit at (",target[0],",",target[1]+1,")")
                                return 1,1,ai_atk_counter,ai_atk_history
                                
                    else:
                        if grid[target[1]][target[0]+1]==0:
                            grid[target[1]][target[0]+1]=-1
                            print("Shot at (",target[0]+1,",",target[1],")")
                            return 0,1,ai_atk_counter,ai_atk_history
                        
                        elif grid[target[1]][target[0]+1]==1:
                            grid[target[1]][target[0]+1]=2
                            print("Hit at (",target[0]+1,",",target[1],")")
                            return 1,1,ai_atk_counter,ai_atk_history
                else:
                    if grid[target[1]-1][target[0]]==0:
                        grid[target[1]-1][target[0]]=-1
                        print("Shot at (",target[0],",",target[1]-1,")")
                        return 0,1,ai_atk_counter,ai_atk_history
                    
                    elif grid[target[1]-1][target[0]]==1:
                        grid[target[1]-1][target[0]]=2
                        print("Hit at (",target[0],",",target[1]-1,")")
                        return 1,1,ai_atk_counter,ai_atk_history
            

def victory_check(player,AI): ## Scans the grids for number of shot ships (coded as '2')
    player_check=0
    AI_check=0
    for ver in range(0,10):
        for hor in range(0,10):
            if player[ver][hor]==2:
                player_check+=1
            if AI[ver][hor]==2:
                AI_check+=1
    
    if player_check==17: ## Total parts of all the ships
        return 0 ## Lose
    elif AI_check==17:
        return 1 ## Win
    else: ## Game will still go on
        return -1


def game_start(loaded,history,counter,aiatk,highscore):

    highscore_counter=2000

    if not(loaded): ## If the game started fresh, not from a saved file
        print(briefing.__doc__)
        input("[] Press enter to continue...")
        
        border()
        print("Commence deployment!!!")
        border()
        
        input("[] Press enter to continue...")
        
        for ship in ship_player.keys():
            border()
            grid_player_ui(grid_player)
            while True:
                temp_grid=grid_player ## uses temporary grid to check placement
                print("Place initial position of",ship,"(",ship_player[ship],"spaces ):")
                border()
                while True:
                    try:
                        x=int(input("Horizontal coordinate: []"))
                        y=int(input("Vertical coordinate: []"))  
                        break
                    except ValueError:
                        input("[] Use numbers only. Try again.")
                        continue
                h_v=hor_or_ver()
                v=ship_place_confirm(x,y,temp_grid,h_v,ship_player,ship,player=True)
                ## uses temporary grid to check placement
                if v: ## If placement is valid, returns True, then official placement will take place
                    ship_place(x,y,grid_player,h_v,ship_player,ship)
                    break        
        grid_player_ui(grid_player)
        input("[] Press enter to continue...")

        border()
        
        for abyssal in ship_AI.keys():            
            while True:
                temp_grid=grid_AI ## uses temporary grid to check placement
                x_a=random.randrange(0,10)
                y_a=random.randrange(0,10)
                h_v=random.choice([True, False])
                ## Reference: https://docs.python.org/3/library/random.html
                ab=ship_place_confirm(x_a,y_a,temp_grid,h_v,ship_AI,abyssal,player=False)
                if ab:
                    ship_place(x_a,y_a,grid_AI,h_v,ship_AI,abyssal)
                    break

                else:
                    continue
            
            print(abyssal,"detected!")
        
        border()
        input("[] Press enter to continue...")
        border()
        print(briefing_intel.__doc__)
        input("[] Press enter to continue...")
        border()

    victory=victory_check(grid_player,grid_AI)
    hit_history,hit_counter=history,counter
    ai_atk=aiatk
    while victory==-1:
        h_c=2 ## turn counter
        border()
        ## Player turn
        
        print("Score:",highscore)
        choice=input("[] attack\n[] status\n[] save\n[] retreat\n\n[]")
        if choice=='attack':
            while h_c==2:
                border()
                grid_AI_ui(grid_AI)
                try:
                    x_fire=int(input("Enter horizontal coordinate: []"))
                    y_fire=int(input("Enter vertical coordinate: []"))
                except ValueError:
                    continue
                border()
                h_c=hitbox_check(grid_AI,x_fire,y_fire,ai_atk,hit_counter,hit_history,ai=False)
                victory=victory_check(grid_player,grid_AI)
                
                ## When the shot is fired at the existing coordinates, it repeats this loop. Else, record score and exit loop
                if h_c==0:
                    highscore_counter-=200
                    highscore-=100
                elif h_c==1:
                    highscore+=highscore_counter
                    highscore_counter=2000
                
            border()
            grid_AI_ui(grid_AI)
            border()
            input("Enemy engaging, brace for impact!\n[]Enter to continue...")
        
        elif choice=='save':
            border()
            hit_counter,ai_atk,highscore=save_data(hit_counter,ai_atk,highscore)
            border()
            continue
        
        elif choice=='retreat':
            border()
            n=input("Are you sure you want to quit?\n[] y [] n:\n[]")
            if n=='y':
                border()
                input("All vessels, retreat!\n[] Press enter to continue...")
                break
            else:
                continue
        
        else: ## If accidentally entered without choice
            continue
        
        border()
        
    ## AI turn
        h_c=2
        while h_c==2:
            x_ai=random.randrange(0,10)
            if x_ai%2==0:
                y_ai=random.randrange(0,10,2)
            else:
                y_ai=random.randrange(1,10,2)
                
            h_c,ai_atk,hit_counter,hit_history=hitbox_check(grid_player,x_ai,y_ai,ai_atk,hit_counter,hit_history,ai=True)
            if h_c==0:
                border()
                grid_player_ui(grid_player)
                victory=victory_check(grid_player,grid_AI)
                input("[] Press enter to continue...")
                
            elif h_c==1:
                highscore-=200
                border()
                grid_player_ui(grid_player)
                victory=victory_check(grid_player,grid_AI)
                input("[] Press enter to continue...")
    
    if victory==0:
        border()
        input("Your fleet has fallen... GAME OVER []")
        if highscore >= 10000:
            border()
            name_hs=input("CONGRATULATIONS ADMIRAL.\nYOU ARE QUALIFIED FOR RECOGNITION.\nSTATE YOUR NAME: ")
            highscore_data[str(highscore)]=name_hs
            data=open("data_highscore.txt","w+")
            data.write(str(highscore_data))
            for score_data in data:
                highscore_data.update(eval(score_data))
            data.close()
            border()
            hs(highscore)
            input("[] Press enter to continue...")
            
    elif victory==1:
        border()
        input("Your fleet is victorious! GAME OVER []")
        if highscore >= 10000:
            border()
            name_hs=input("CONGRATULATIONS ADMIRAL.\nYOU ARE QUALIFIED FOR RECOGNITION.\nSTATE YOUR NAME: ")
            highscore_data[str(highscore)]=name_hs
            data=open("data_highscore.txt","w+")
            data.write(str(highscore_data))
            for score_data in data:
                highscore_data.update(eval(score_data))
            data.close()
            border()
            hs(highscore_data)
            input("[] Press enter to continue...")


### Sensitive coding. DO NOT EDIT! ###
######################################
### Sensitive coding. DO NOT EDIT! ###

def load_data(count,ai_atk,loaded,highscore):
    try:
        i=0
        data=open("data_battleship_alt.txt","r")
    except FileNotFoundError:
        input("Load file does not exist... Press enter to continue... []")
        return count,ai_atk,loaded,highscore
    
    for line in data:
        temp_data=eval(line)
        if i==0:
            for x in temp_data:
                grid_player.append(x)
            i+=1
            continue
        elif i==1:
            for x in temp_data:
                grid_AI.append(x)
            i+=1
            continue
        elif i==2:
            hit_history.update(temp_data)
            i+=1
            continue
        elif i==3:
            count=int(line)
            i+=1
            continue
        elif i==4:
            ai_atk=int(line)
            i+=1
            continue
        elif i==5:
            highscore=int(line)
    input("Loaded!")
    data.close()
    loaded = True
    return count,ai_atk,loaded,highscore

def save_data(count,ai_atk,highscore):
    data=open("data_battleship_alt.txt","w")
    data.write(str(grid_player) + "\n")
    data.write(str(grid_AI) + "\n")
    data.write(str(hit_history) + "\n")
    data.write(str(count) + "\n")
    data.write(str(ai_atk) + "\n")
    data.write(str(highscore) + "\n")
    input("Saved!")
    data.close()
    return count,ai_atk,highscore

def hs(hs_data):
    len_scores=len(hs_data)
    for score,name in sorted(hs_data.items(),reverse=True):
        print(name,score)
        print()
    if len_scores>=10:
        print("Scroll up")
    return

highscore_data={'30000':"Marshal Admiral Silica",'25000':"Vice Admiral Isokuoro",'20000':"Front Admiral Hawkins",'15000':"Rear Admiral Dreams",'12500':"Captain Tin-tin"}

grid_player=[]
grid_AI=[]

ship_player={'Aircraft Carrier':5,'Battleship':4,'Heavy Cruiser':3,'Light Cruiser':3,'Destroyer':2}
ship_AI={'Wo-class Carrier':5,'Re-class Battleship':4,'Ri-class Cruiser':3,'Tsu-class Cruiser':3,'Ho-class Destroyer':2}
hit_history={}                ## AI USE
hit_counter=0                 ## AI USE
ai_atk=0
highscore=0

### Sensitive coding. DO NOT EDIT! ###
######################################
### Sensitive coding. DO NOT EDIT! ###

## Backup high score data
highscore_data={'40000':"Marshal Admiral Silica",'30000':"Vice Admiral Isokuoro",'20000':"Front Admiral Hawkins",'15000':"Rear Admiral Dreams",'12500':"Captain Tin-tin"}

## Initialize high score data from an existing file. Else, game will use the line of code above this for backup

file_hs=False

try:
    data=open("data_highscore.txt","r")
    file_hs=True
except FileNotFoundError:
    pass
if file_hs:
    for score_data in data:
        highscore_data.update(eval(score_data))
    data.close()


try:
    quotes()
except KeyboardInterrupt:
    pass

while True:
    load=False
    border()
    print(menu.__doc__)
    select=input("[]")
    if select=='start':
        border()
        input("Welcome to battleship!\nEnjoy the game\n[] Press enter to continue...")
        border()
        grid_player=initialize_grid()
        grid_AI=initialize_grid()
        hit_history={}
        hit_counter=0
        ai_atk=0
        game_start(load,hit_history,hit_counter,ai_atk,highscore)
    elif select=='load':
        hit_counter,ai_atk,load,highscore=load_data(hit_counter,ai_atk,load,highscore)
        if load:
            game_start(load,hit_history,hit_counter,ai_atk,highscore)
        else:
            continue
    elif select=='hall of fame':
        border()
        hs(highscore_data)
        border()
        input("[] Press enter to continue...")
    elif select=='exit':
        border()
        input("Farewell, admiral.\n\n[] Press enter to exit...")
        print("\n"*50)
        break
    
    elif select=='DEV MODE':
        dev(select)
